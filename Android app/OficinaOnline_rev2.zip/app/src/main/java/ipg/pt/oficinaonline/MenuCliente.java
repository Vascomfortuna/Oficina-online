package ipg.pt.oficinaonline;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MenuCliente extends AppCompatActivity {
    String pnome,unome;
    int id = 0;
    TextView campoUtilizador;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_cliente);

        Intent intent = getIntent();
        pnome = intent.getStringExtra(MainActivity.EXTRA_PNOME);
        unome = intent.getStringExtra(MainActivity.EXTRA_UNOME);
        id = intent.getIntExtra(MainActivity.EXTRA_IDCLIENTE,0);

        campoUtilizador = (TextView) findViewById(R.id.textViewMenuCliente);
        campoUtilizador.setText("Bem-vindo, "+pnome+" "+unome+".");

    }

    public void BotaoVerVeiculos(View view){
        Intent intent = new Intent(this, ClienteVerVeiculos.class);
        intent.putExtra(MainActivity.EXTRA_IDCLIENTE,id);
        startActivity(intent);
    }

    public void BotaoRegistarVeiculo(View view){
        Intent intent = new Intent(this, RegistarVeiculo.class);
        intent.putExtra(MainActivity.EXTRA_IDCLIENTE,id);
        startActivity(intent);
    }
}
