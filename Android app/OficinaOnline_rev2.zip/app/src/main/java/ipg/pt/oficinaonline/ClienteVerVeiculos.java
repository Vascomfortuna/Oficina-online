package ipg.pt.oficinaonline;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class ClienteVerVeiculos extends AppCompatActivity {
    private static final String TAG = ClienteRepository.class.getName();
    Cursor cursorVeiculos;
    ListView listView;
    ArrayAdapter<String> adapter;
    ArrayList<String> listItems = new ArrayList<String>();
    String resul, s;
    String[] param = new String[3];
    JSONArray jArray;
    JSONObject oneObject;

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cliente_ver_veiculos);
        try {

            param[0] = MainActivity.id + "";
            param[1] = MainActivity.email;
            param[2] = MainActivity.pass;

            if (isNetworkAvailable()) {
                // Online - ler dados do Web Service
                resul = new WebServiceBuscarVeiculos().execute(param).get();
                jArray = new JSONArray(resul);
                for (int i = 0; i < jArray.length(); i++) {
                    oneObject = jArray.getJSONObject(i);
                    s = "Marca: " + oneObject.getString("Marca") + ".\nModelo: " + oneObject.getString("Modelo")
                            + ".\nMatricula: " + oneObject.getString("Matricula") + ".\nConsumo total: " + oneObject.getString("Litros") + ".";
                    listItems.add(s);
                }
            } else {
                // Offline - ler dados do SQLite
                DatabaseHelper dbHelper = new DatabaseHelper(this);
                SQLiteDatabase db = dbHelper.getReadableDatabase();
                final VeiculoRepository veiculoRepository = new VeiculoRepository(db);
                cursorVeiculos = veiculoRepository.getAllItemsFiltered(Long.toString(MainActivity.cliente.getId()));
                while (cursorVeiculos.moveToNext()) {
                    s = "Marca: " + cursorVeiculos.getString(cursorVeiculos.getColumnIndex("Marca")) + ".\n"
                            + "Modelo: " + cursorVeiculos.getString(cursorVeiculos.getColumnIndex("Modelo")) + ".\n"
                            + "Matricula: " + cursorVeiculos.getString(cursorVeiculos.getColumnIndex("Matricula"));
                    listItems.add(s);
                }
                cursorVeiculos.close();
                db.close();
            }

            // Mostrar na ListView
            listView = (ListView) findViewById(R.id.list);
            adapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1,
                    listItems);
            listView.setAdapter(adapter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
