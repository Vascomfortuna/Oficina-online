package ipg.pt.oficinaonline;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;
import android.util.Log;

import java.sql.SQLException;

/**
 * Created by CirculesX on 06/02/2017.
 */

public class VeiculoRepository implements BaseColumns {

    private static final String TAG = VeiculoRepository.class.getName();
    private static final String TABLE_NAME = "bd_veiculos";
    private static final String FIELD_ID_MARCA = "IdMarca";
    private static final String FIELD_ID_MODELO = "IdModelo";
    private static final String FIELD_ID_CLIENTE = "IdCliente";
    private static final String FIELD_MATRICULA = "Matricula";
    private static final String FIELD_MARCA = "Marca";
    private static final String FIELD_MODELO = "Modelo";
    private SQLiteDatabase db;

    public VeiculoRepository(SQLiteDatabase db) {
        this.db = db;
    }

    public void create() throws SQLException {
        db.execSQL("CREATE TABLE " + TABLE_NAME + "(" +
                _ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                FIELD_ID_MARCA + " INTEGER NOT NULL," +
                FIELD_ID_MODELO + " INTEGER NOT NULL," +
                FIELD_ID_CLIENTE + " INTEGER NOT NULL," +
                FIELD_MATRICULA + " TEXT NOT NULL," +
                FIELD_MARCA + " TEXT NOT NULL," +
                FIELD_MODELO + " TEXT NOT NULL" +
                ");"
        );

        if (Globals.DUMMY_DATA) {
            // gravar 5 registros na tabela
            String IdMarca, IdModelo, IdCliente, Matricula, Marca, Modelo;
            for (int i=1; i<=5; i++) {
                IdMarca = "" + i;
                IdModelo = "" + i;
                IdCliente = "" + i;
                Matricula = "AA-BB-" + i;
                Marca = "Marca " + i;
                Modelo = "Modelo " + i;
                db.execSQL("INSERT INTO "
                        + TABLE_NAME
                        + " ("
                        + FIELD_ID_MARCA + ", "
                        + FIELD_ID_MODELO + ", "
                        + FIELD_ID_CLIENTE + ", "
                        + FIELD_MATRICULA + ", "
                        + FIELD_MARCA + ", "
                        + FIELD_MODELO
                        + ") VALUES ("
                        + "'" + IdMarca + "', "
                        + "'" + IdModelo + "', "
                        + "'" + IdCliente + "', "
                        + "'" + Matricula + "', "
                        + "'" + Marca + "', "
                        + "'" + Modelo + "'"
                        + ");"
                );
            }
        }
    }

    public long insert(Veiculo veiculo) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(FIELD_ID_MARCA, veiculo.getIdMarca());
        contentValues.put(FIELD_ID_MODELO, veiculo.getIdModelo());
        contentValues.put(FIELD_ID_CLIENTE, veiculo.getIdCliente());
        contentValues.put(FIELD_MATRICULA, veiculo.getMatricula());
        contentValues.put(FIELD_MARCA, veiculo.getMarca());
        contentValues.put(FIELD_MODELO, veiculo.getModelo());
        return db.insertOrThrow(TABLE_NAME, null, contentValues);
    }

    public Cursor getAllItems() {
        String [] dbColumns = new String[] {
                _ID,
                FIELD_ID_MARCA,
                FIELD_ID_MODELO,
                FIELD_ID_CLIENTE,
                FIELD_MATRICULA,
                FIELD_MARCA,
                FIELD_MODELO
        };
        return db.query(TABLE_NAME, dbColumns, null, null, null, null, FIELD_MATRICULA + " COLLATE NOCASE");
    }

    /**
     * Veículos de um determinado cliente
     * @param filterString ID do cliente
     * @return Cursor Lista de Veículos de um cliente
     */
    public Cursor getAllItemsFiltered(String filterString) {
        String sql = "SELECT "
                + _ID + ", "
                + FIELD_MARCA + ", "
                + FIELD_MODELO + ", "
                + FIELD_MATRICULA + " "
                + "FROM " + TABLE_NAME + " "
                + "WHERE " + FIELD_ID_CLIENTE + " LIKE ?";
        Log.d(TAG, "sql -> "+sql);
        return db.rawQuery(
                sql,
                new String[] {
                        '%'+filterString+'%'
                }
        );
    }

    public Veiculo getItem(long Id) {
        String [] dbColumns = new String[] {
                _ID,
                FIELD_ID_MARCA,
                FIELD_ID_MODELO,
                FIELD_ID_CLIENTE,
                FIELD_MATRICULA,
                FIELD_MARCA,
                FIELD_MODELO
        };
        Cursor cursor = db.query(
                TABLE_NAME,
                dbColumns,
                _ID+"=?",
                new String[] {String.valueOf(Id)},
                null, null, null
        );
        if (!cursor.moveToFirst()) {
            return null;
        }
        int IdMarca = cursor.getInt(cursor.getColumnIndex(FIELD_ID_MARCA));
        int IdModelo = cursor.getInt(cursor.getColumnIndex(FIELD_ID_MODELO));
        int IdCliente = cursor.getInt(cursor.getColumnIndex(FIELD_ID_CLIENTE));
        String Matricula = cursor.getString(cursor.getColumnIndex(FIELD_MATRICULA));
        String Marca = cursor.getString(cursor.getColumnIndex(FIELD_MARCA));
        String Modelo = cursor.getString(cursor.getColumnIndex(FIELD_MODELO));
        return new Veiculo(
                Id,
                IdMarca,
                IdModelo,
                IdCliente,
                Matricula,
                Marca,
                Modelo
        );
    }

    public void update(Veiculo veiculo) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(FIELD_ID_MARCA, veiculo.getIdMarca());
        contentValues.put(FIELD_ID_MODELO, veiculo.getIdModelo());
        contentValues.put(FIELD_ID_CLIENTE, veiculo.getIdCliente());
        contentValues.put(FIELD_MATRICULA, veiculo.getMatricula());
        contentValues.put(FIELD_MARCA, veiculo.getMarca());
        contentValues.put(FIELD_MODELO, veiculo.getModelo());
        db.update(TABLE_NAME, contentValues, _ID+"=?", new String[] {Long.toString(veiculo.getId())});
    }

    public long delete(Veiculo veiculo) {
        return db.delete(TABLE_NAME, _ID+"=?", new String[] {String.valueOf(veiculo.getId())});
    }

    public void drop() {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME+";");
    }

}
