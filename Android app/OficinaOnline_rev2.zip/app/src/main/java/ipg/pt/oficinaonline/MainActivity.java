package ipg.pt.oficinaonline;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.ExecutionException;

import static java.sql.Types.NULL;

public class MainActivity extends AppCompatActivity {
    public static Cliente cliente;
    String[] s = new String[2];
    EditText mEmail,mPassword;
    String resul;
    Context context;
    CharSequence text;
    int duration;
    Toast toast;
    JSONObject oneObject;
    public final static String EXTRA_PNOME= "ipg.pt.testescodigo.PNOME";
    public final static String EXTRA_IDCLIENTE = "ipg.pt.testescodigo.IDCLIENTE";
    public final static String EXTRA_UNOME = "ipg.pt.testescodigo.UNOME";
    public final static String EXTRA_EMAIL = "ipg.pt.testescodigo.EMAIL";
    public final static String EXTRA_PASSWORD = "ipg.pt.testescodigo.PASSWORD";
    public  static String pnome,unome,email,pass = null;
    public  static int id = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mEmail = (EditText) findViewById(R.id.editTextEmail);
        mPassword = (EditText) findViewById(R.id.editTextPassword);
        context = getApplicationContext();
        duration = Toast.LENGTH_SHORT;

    }

    public void BotaoLogin(View view){
        s[0] = mEmail.getText().toString();
        s[1] = mPassword.getText().toString();
        try {
            // Hash SHA256
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(s[1].getBytes("UTF-8")); // Change this to "UTF-16" if needed
            byte[] digest = md.digest();
            String hash = String.format("%064x", new java.math.BigInteger(1, digest));
            s[1] = hash.toUpperCase();

            //TextView textViewHash = (TextView) findViewById(R.id.textViewHash);
            //textViewHash.setText(hash);

            resul = new WebServiceLogin().execute(s).get();
            oneObject = new JSONObject(resul);
            pnome = oneObject.getString("primeiroNome");
            unome = oneObject.getString("ultimoNome");
            email = oneObject.getString("email");
            pass = oneObject.getString("password");
            id = oneObject.getInt("idCliente");
            cliente = new Cliente(id, pnome, unome, "", email, pass, "", NULL);

            if(!pnome.equals("0")){
                if(id==1){
                    Intent intent = new Intent(this, MenuCliente.class);
                    intent.putExtra(EXTRA_PNOME, pnome);
                    intent.putExtra(EXTRA_UNOME, unome);
                    intent.putExtra(EXTRA_IDCLIENTE, id);
                    intent.putExtra(EXTRA_EMAIL, email);
                    intent.putExtra(EXTRA_PASSWORD, pass);
                    startActivity(intent);
                }
            }else{
                text = "Login ou password errada.";
                toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

}
