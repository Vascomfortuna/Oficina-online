package ipg.pt.oficinaonline;

/**
 * Created by Sandro on 01/02/2017.
 */

public final class Globals {

    private Globals() {
        throw new AssertionError();
    }

    public static final boolean DUMMY_DATA = true;

}
