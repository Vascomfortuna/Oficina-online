package ipg.pt.oficinaonline;

/**
 * Created by Sandro on 02/02/2017.
 * Cliente - Entity - Data model - POJO model
 */

public class Cliente {

    private long Id;
    private String PrimeiroNome;
    private String UltimoNome;
    private String Telemovel;
    private String Email;
    private String Password;
    private String Genero;
    private int Sync;

    public Cliente(long Id, String PrimeiroNome, String UltimoNome, String Telemovel, String Email, String Password, String Genero, int Sync) {
        this.Id = Id;
        this.PrimeiroNome = PrimeiroNome;
        this.UltimoNome = UltimoNome;
        this.Telemovel = Telemovel;
        this.Email = Email;
        this.Password = Password;
        this.Genero = Genero;
        this.Sync = Sync;
    }

    public long getId() {
        return Id;
    }

    public String getPrimeiroNome() {
        return PrimeiroNome;
    }

    public String getUltimoNome() {
        return UltimoNome;
    }

    public String getTelemovel() {
        return Telemovel;
    }

    public String getEmail() {
        return Email;
    }

    public String getPassword() {
        return Password;
    }

    public String getGenero() {
        return Genero;
    }

    public int getSync() {
        return Sync;
    }

}
