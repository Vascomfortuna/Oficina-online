package ipg.pt.oficinaonline;

/**
 * Created by Sandro on 06/02/2017.
 * Vaiculo - Entity - Data model - POJO model
 */

public class Veiculo {

    private long Id;
    private long IdMarca;
    private long IdModelo;
    private long IdCliente;
    private String Matricula;
    private String Marca;
    private String Modelo;

    public Veiculo(long Id, long IdMarca, long IdModelo, long IdCliente, String Matricula, String Marca, String Modelo) {
        this.Id = Id;
        this.IdMarca = IdMarca;
        this.IdModelo = IdModelo;
        this.IdCliente = IdCliente;
        this.Matricula = Matricula;
        this.Marca = Marca;
        this.Modelo = Modelo;
    }

    public long getId() {
        return Id;
    }

    public long getIdMarca() {
        return IdMarca;
    }

    public long getIdModelo() {
        return IdModelo;
    }

    public long getIdCliente() {
        return IdCliente;
    }

    public String getMatricula() {
        return Matricula;
    }

    public String getMarca() {
        return Marca;
    }

    public String getModelo() {
        return Modelo;
    }

}
