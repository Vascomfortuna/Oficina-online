package ipg.pt.oficinaonline;

import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

/**
 * Created by vasco on 27/01/2017.
 */

public class WebServiceLogin  extends AsyncTask<String[], Void,String> {
    @Override
    protected String doInBackground(String[]... strings) {
        String[] s = strings[0];
        HttpURLConnection con = null;
        try {
            URL url = new URL("http://bd.ipg.pt:8080/alunos/bda_1010985.WS.ws_login?vemail=" + s[0] + "&vpassword=" + s[1]);
            con = (HttpURLConnection) url.openConnection();
            InputStream in = con.getInputStream();
            Scanner scanner = new Scanner(in);
            scanner.useDelimiter("\\A"); // read all the file
            if (scanner.hasNext()) {
                return scanner.next();

            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            con.disconnect();
        }
        return null;
    }
}
