package ipg.pt.oficinaonline;

import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;

/**
 * Created by vasco on 01/02/2017.
 */

public class WebServiceBuscarVeiculos extends AsyncTask<String[], Void,String> {
    @Override
    protected String doInBackground(String[]... strings) {
        String[] s = strings[0];
        HttpURLConnection con = null;
        try {
            URL url = new URL("http://bd.ipg.pt:8080/alunos/bda_1010985.WS.WS_VERVEICULOS" +
                    "?id_cliente=" + s[0] + "&v_email=" + s[1] +"&v_password=" +s[2]);
            con = (HttpURLConnection) url.openConnection();
            InputStream in = con.getInputStream();
            Scanner scanner = new Scanner(in);
            scanner.useDelimiter("\\A"); // read all the file
            if (scanner.hasNext()) {
                return scanner.next();

            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            con.disconnect();
        }
        return null;
    }
}