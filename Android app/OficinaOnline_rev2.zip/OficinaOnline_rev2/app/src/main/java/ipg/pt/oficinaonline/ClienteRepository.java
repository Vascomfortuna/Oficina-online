package ipg.pt.oficinaonline;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;
import android.util.Log;

import java.sql.SQLException;

/**
 * Created by CirculesX on 06/02/2017.
 */

public class ClienteRepository implements BaseColumns {

    private static final String TAG = ClienteRepository.class.getName();
    private static final String TABLE_NAME = "bd_clientes";
    private static final String FIELD_PRIMEIRO_NOME = "PrimeiroNome";
    private static final String FIELD_ULTIMO_NOME = "UltimoNome";
    private static final String FIELD_TELEMOVEL = "Telemovel";
    private static final String FIELD_EMAIL = "Email";
    private static final String FIELD_PASSWORD = "Password";
    private static final String FIELD_GENERO = "Genero";
    private static final String FIELD_SYNC = "Sync";
    private SQLiteDatabase db;

    public ClienteRepository(SQLiteDatabase db) {
        this.db = db;
    }

    public void create() throws SQLException {
        db.execSQL("CREATE TABLE " + TABLE_NAME + "(" +
                _ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                FIELD_PRIMEIRO_NOME + " TEXT NOT NULL," +
                FIELD_ULTIMO_NOME + " TEXT NOT NULL," +
                FIELD_TELEMOVEL + " TEXT NOT NULL," +
                FIELD_EMAIL + " TEXT NOT NULL," +
                FIELD_PASSWORD + " TEXT NOT NULL," +
                FIELD_GENERO + " TEXT," +
                FIELD_SYNC + " INTEGER" +
                ");"
        );

        if (Globals.DUMMY_DATA) {
            // gravar 5 registros na tabela
            String PrimeiroNome, UltimoNome, Telemovel, Email, Password, Genero, Sync;
            for (int i=1; i<=5; i++) {
                PrimeiroNome = "Mecânico";
                UltimoNome = "n. " + i;
                Telemovel = "Telemovel " + i;
                Email = "mecanico" + i + "@mecman.pt";
                Password = "segredo";
                Genero = "m";
                Sync = "0";
                db.execSQL("INSERT INTO "
                        + TABLE_NAME
                        + " ("
                        + FIELD_PRIMEIRO_NOME + ", "
                        + FIELD_ULTIMO_NOME + ", "
                        + FIELD_TELEMOVEL + ", "
                        + FIELD_EMAIL + ", "
                        + FIELD_PASSWORD + ", "
                        + FIELD_GENERO + ", "
                        + FIELD_SYNC
                        + ") VALUES ("
                        + "'" + PrimeiroNome + "', "
                        + "'" + UltimoNome + "', "
                        + "'" + Telemovel + "', "
                        + "'" + Email + "', "
                        + "'" + Password + "', "
                        + "'" + Genero + "', "
                        + "'" + Sync + "'"
                        + ");"
                );
            }
        }

    }

    public long insert(Cliente cliente) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(FIELD_PRIMEIRO_NOME, cliente.getPrimeiroNome());
        contentValues.put(FIELD_ULTIMO_NOME, cliente.getUltimoNome());
        contentValues.put(FIELD_TELEMOVEL, cliente.getTelemovel());
        contentValues.put(FIELD_EMAIL, cliente.getEmail());
        contentValues.put(FIELD_PASSWORD, cliente.getPassword());
        contentValues.put(FIELD_GENERO, cliente.getGenero());
        contentValues.put(FIELD_SYNC, cliente.getSync());
        return db.insertOrThrow(TABLE_NAME, null, contentValues);
    }

    public Cursor getAllItems() {
        String [] dbColumns = new String[] {
                _ID,
                FIELD_PRIMEIRO_NOME,
                FIELD_ULTIMO_NOME,
                FIELD_TELEMOVEL,
                FIELD_EMAIL,
                FIELD_PASSWORD,
                FIELD_GENERO,
                FIELD_SYNC
        };
        return db.query(TABLE_NAME, dbColumns, null, null, null, null, FIELD_PRIMEIRO_NOME + " COLLATE NOCASE");
    }

    public Cursor getAllItemsFiltered(String filterString) {
        String sql = "SELECT "+_ID+", "+FIELD_PRIMEIRO_NOME+", "+FIELD_ULTIMO_NOME
                + " FROM " + TABLE_NAME
                + " WHERE "+FIELD_PRIMEIRO_NOME+" LIKE ?";
        Log.d(TAG, "sql -> "+sql);
        return db.rawQuery(
                sql,
                new String[] {
                        '%'+filterString+'%'
                }
        );
    }

    public Cliente getItem(long Id) {
        String [] dbColumns = new String[] {
                _ID,
                FIELD_PRIMEIRO_NOME,
                FIELD_ULTIMO_NOME,
                FIELD_TELEMOVEL,
                FIELD_EMAIL,
                FIELD_PASSWORD,
                FIELD_GENERO,
                FIELD_SYNC
        };
        Cursor cursor = db.query(
                TABLE_NAME,
                dbColumns,
                _ID+"=?",
                new String[] {String.valueOf(Id)},
                null, null, null
        );
        if (!cursor.moveToFirst()) {
            return null;
        }
        String PrimeiroNome = cursor.getString(cursor.getColumnIndex(FIELD_PRIMEIRO_NOME));
        String UltimoNome = cursor.getString(cursor.getColumnIndex(FIELD_ULTIMO_NOME));
        String Telemovel = cursor.getString(cursor.getColumnIndex(FIELD_TELEMOVEL));
        String Email = cursor.getString(cursor.getColumnIndex(FIELD_EMAIL));
        String Password = cursor.getString(cursor.getColumnIndex(FIELD_PASSWORD));
        String Genero = cursor.getString(cursor.getColumnIndex(FIELD_GENERO));
        int Sync = cursor.getInt(cursor.getColumnIndex(FIELD_SYNC));
        return new Cliente(
                Id,
                PrimeiroNome,
                UltimoNome,
                Telemovel,
                Email,
                Password,
                Genero,
                Sync
        );
    }

    public void update(Cliente cliente) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(FIELD_PRIMEIRO_NOME, cliente.getPrimeiroNome());
        contentValues.put(FIELD_ULTIMO_NOME, cliente.getUltimoNome());
        contentValues.put(FIELD_TELEMOVEL, cliente.getTelemovel());
        contentValues.put(FIELD_EMAIL, cliente.getEmail());
        contentValues.put(FIELD_PASSWORD, cliente.getPassword());
        contentValues.put(FIELD_GENERO, cliente.getGenero());
        contentValues.put(FIELD_SYNC, cliente.getSync());
        db.update(TABLE_NAME, contentValues, _ID+"=?", new String[] {Long.toString(cliente.getId())});
    }

    public long delete(Cliente cliente) {
        return db.delete(TABLE_NAME, _ID+"=?", new String[] {String.valueOf(cliente.getId())});
    }

    public void drop() {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME+";");
    }

}
