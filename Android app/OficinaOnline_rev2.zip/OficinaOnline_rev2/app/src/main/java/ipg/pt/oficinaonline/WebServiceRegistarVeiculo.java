package ipg.pt.oficinaonline;

import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;

/**
 * Created by vasco on 30/01/2017.
 */

public class WebServiceRegistarVeiculo extends AsyncTask<String[], Void,String> {
    @Override
    protected String doInBackground(String[]... strings) {
        String[] s = strings[0];
        HttpURLConnection con = null;
        try {
            URL url = new URL("http://bd.ipg.pt:8080/alunos/bda_1010985.WS.WS_RegistaVeiculo" +
                    "?v_idmarca=" + s[0] + "&v_idmodelo=" + s[1]+
                    "&v_marca=" + URLEncoder.encode(s[2],"utf-8") + "&v_modelo=" + URLEncoder.encode(s[3],"utf-8")+
                    "&v_matricula=" + s[4] + "&v_idcliente=" + s[5] +
                    "&v_email=" + s[6] + "&v_password=" + s[7]);
            con = (HttpURLConnection) url.openConnection();
            InputStream in = con.getInputStream();
            Scanner scanner = new Scanner(in);
            scanner.useDelimiter("\\A"); // read all the file
            if (scanner.hasNext()) {
                return scanner.next();

            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            con.disconnect();
        }
        return null;
    }
}
